package roadgraph;

import geography.GeographicPoint;

public class MapEdges {
	private MapNode start;
	private MapNode end;
	private String StreetName;
	private String StreetType;
	private double distance;
	
	public MapEdges(MapNode n1,MapNode n2,String name,String type,double dis) {
		this.start = n1;
		this.end = n2;
		this.StreetName = name;
		this.StreetType = type;
		this.distance = dis;
		
	}
	
	public MapNode getEndNode() {
		   return end;
	}
		
	// return the location of the start point
	public	GeographicPoint getStartPoint(){
			return start.getLocation();
	}
		
	// return the location of the end point
	public	GeographicPoint getEndPoint(){
			return end.getLocation();
	}
		
	// return the distance
	public double getDistance(){
			return distance;
	}
		
		
		
	// return street name
	public String getStreetName(){
		return StreetName;
	}
	
	// given one node in an edge, return the other node
	public MapNode getOtherNode(MapNode node)
	{
		if (node.equals(start)) 
			return end;
		else if (node.equals(end))
			return start;
		throw new IllegalArgumentException("Looking for " +
			"a point that is not in the edge");
	}
	
	// return String containing details about the edge
	public String toString()
	{
		String toReturn = "[EDGE between ";
		toReturn += "\n\t" + start.getLocation();
		toReturn += "\n\t" + end.getLocation();
		toReturn += "\nStreet name: " + StreetName + " Street type: " + StreetType +
				" edge distance: " + String.format("%.3f", distance) + "km";
		
		return toReturn;
	}
	
}
