package roadgraph;
import java.util.HashSet;
import java.util.Set;

import geography.GeographicPoint;

/**
 * @author:Jiaxi Gao
 * 
 * Class representing a vertex (or node) in our MapGraph
 *
 */
public class MapNode {
	/** The list of edges of this node */
	private HashSet<MapEdges> edges;
	
	/** the latitude and longitude of this node */
	private GeographicPoint location;
	
	/** Constructor*/
	public MapNode(GeographicPoint location) {
		this.location = location;
		this.edges = new HashSet<MapEdges>();
	}
	
	protected void addEdge(MapEdges edge) {
		edges.add(edge);
	}
	
	protected GeographicPoint getLocation()
	{
		return location;
	}
	
	protected Set<MapEdges> getEdges(){
		return edges;
	}
	
	protected Set<MapNode> getNeighbors(){
		Set<MapNode> neighbors = new HashSet<MapNode>();
		for (MapEdges edge:edges) {
			neighbors.add(edge.getOtherNode(this));
		}
		return neighbors;
	}
	/** ToString to print out a MapNode object
	 *  @return the string representation of a MapNode
	 */
	public String toString()
	{
		String toReturn = "[NODE at location (" + location + ")";
		toReturn += " intersects streets: ";
		for (MapEdges e: edges) {
			toReturn += e.getStreetName() + ", ";
		}
		toReturn += "]";
		return toReturn;
	}
	
}
